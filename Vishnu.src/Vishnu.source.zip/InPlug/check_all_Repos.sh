#!/bin/bash
# Script zum �berpr�fen aller Arbeitsverzeichnisse unterhalb des aktuellen
# Verzeichnisses auf Aktualit�t und Synchronit�t mit dem remote-Repository.
# 07.06.2020 Erik Nagel: erstellt.
# 24.01.2025 Erik Nagel: Darstellung der Pr�fergebnisse gestrafft und in Farbe.

die() { echo "$@" 1>&2 ; exit 1; }

# Definition von Farbvariablen
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # Keine Farbe

# function to list a single remote status
checkRepoStatus() {
	actRemote=$1
	actBranch=$2
  #echo git fetch "$actRemote" "$actBranch"
  git fetch "$actRemote" "$actBranch" >/dev/null 2>&1
  # echo git diff "${actRemote}/${actBranch}" "$actBranch:"
	git_diff=$(git diff "${actRemote}/${actBranch}" "$actBranch" | head -1)
	# echo _____ $git_diff _____
	if [[ "$git_diff" =~ "diff" ]]; then
		echo -e "${YELLOW}${actRemote} HANDLUNGSBEDARF!${NC}"
		git diff "${actRemote}/${actBranch}" "$actBranch" | head -5
	fi
}

# function for a single repo (locally)
workOnRepo() {
	# echo
	orgDir="$(pwd)"
	cd $1 || die "Fehler beim Wechsel nach $1"
	# get the root directory in case you run script from deeper into the repo
	
	gitRoot="$(git rev-parse --show-toplevel)"

	cd "$gitRoot" || die "Fehler beim Wechsel nach $gitRoot"
	wd=$(pwd)
	# echo "---------------------------------------------------------------------------------------------------"
  git fetch --prune
	# echo git status
	
  # git status
  git_status=$(git status)
  
  if [[ "$git_status" =~ "Your branch is up to date with 'origin/master'" ]] &&
  	 [[ "$git_status" =~ "nothing to commit, working tree clean" ]]; then
    echo -e "${GREEN}$wd ALLES OK.${NC}"
  elif [[ "$git_status" =~ "Your branch is up to date with " ]] &&
  	 [[ "$git_status" =~ "nothing to commit, working tree clean" ]]; then
    echo -e "${YELLOW}$wd Achtung, anderer Branch!${NC}"
  else
    echo -e "${RED}$wd HANDLUNGSBEDARF!${NC}"
    git status
  fi
	echo "---------------------------------------------------------------------------------------------------"

  trackedRemote=$(git status -sb|grep '##'|sed -e 's/## //'|sed -e 's/.*\.\.\.//'|sed -e 's/\/.*//')
  actBranch=$(git branch --show-current)
	for actRemote in $(git remote|grep -v "$trackedRemote"); do checkRepoStatus $actRemote $actBranch; done

  lastLogText=$(git log --name-status HEAD^..HEAD 2>/dev/null|grep "    "|sed "s/^ \+//")
  if [[ -z $lastLogText ]]
	then
	  lastLogText=$(git log --name-status HEAD|grep "    "|sed "s/^ \+//")
	fi

  lastLongLogDate=$(git log --name-status HEAD^..HEAD 2>/dev/null|grep "Date:"|sed "s/Date:\s*//"|sed "s/ +.*//"|head -1)
  if [[ -z $lastLongLogDate ]]
	then
	  lastLongLogDate=$(git log --name-status HEAD|grep "Date:"|sed "s/Date:\s*//"|sed "s/ +.*//"|head -1)
	fi

  lastLogDate=$(date -d"$lastLongLogDate" +%d.%m.%Y)

  lastLogAuthor=$(git log --name-status HEAD^..HEAD 2>/dev/null|grep "Author:"|sed "s/\s*<.*//"|sed "s/Author: //")
  if [[ -z $lastLogAuthor ]]
	then
	  lastLogAuthor=$(git log --name-status HEAD|grep "Author:"|sed "s/\s*<.*//"|sed "s/Author: //")
	fi
 
	# echo "${lastLogDate} ${lastLogAuthor}: ${lastLogText}"
	cd "$orgDir" || die "Fehler beim Wechsel nach $orgDir"
}

# Main
echo "Nachfolgende Verzeichnisse werden verarbeitet:"
echo "---------------------------------------------------------------------------------------------------"
ls -d ./*/|grep -iv '_Develop'|grep -iv '_Archiv'|grep -iv '_Assemblies_for_BasicApplication_nuget'|sed "s/\.\///g"|sed "s/\///g"|tr '\n' ' ';
# begin status
echo
echo "---------------------------------------------------------------------------------------------------"
echo
for dir in $(ls -d ./*/|grep -iv '_Develop'|grep -iv '_Archiv'|grep -iv '_Assemblies_for_BasicApplication_nuget'); do workOnRepo $dir; done
echo "---------------------------------------------------------------------------------------------------"
echo "--- Ende ---"
echo "---------------------------------------------------------------------------------------------------"
