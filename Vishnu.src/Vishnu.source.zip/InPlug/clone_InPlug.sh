#!/bin/bash
# Script zum clonen aller InPlug-Repositories in das aktuelle Verzeichnis.
# 07.06.2020 Erik Nagel: erstellt.
# 31.01.2022 Erik Nagel: MicroMailer von WorkFrame nach hierhin verschoben.

die() { echo "$@" 1>&2 ; exit 1; }

# function for cloning a single remote repo
workOnRepo() {
	repo=$1
	[ -d "./${repo}" ] && die "Das Verzeichnis ./${repo} existiert schon."	
	[ -d "./${repo%.git}" ] && die "Das Verzeichnis ./${repo%.git} existiert schon."	
	repoBasisUrl=${2%/}
	git clone "${repoBasisUrl}/${repo}"
}

# Main
if git rev-parse --git-dir > /dev/null 2>&1; then
 	die "Das Verzeichnis ${pwd} enthaelt schon ein git-Repository. Clone ist hier nicht zulaessig."
fi
echo "Nachfolgende Repositories werden in das aktuelle Verzeichnis $(pwd) gecloned:"
echo "AddOn.git, CheckDate.git, CheckDiskSpace.git, CheckerHistoryLogger, CheckServer.git, ConsoleLogger.git,"
echo "ConsoleMessageBox.git, DateTo_01_15.git, DateToMoonAge.git, DemoParameterProvider.git, DemoWPFCanRunDialog.git,"
echo "Escalator.git, FileChecker.git, FileWatcherTrigger.git, Log2MessageBox.git, MicroMailer.git,"
echo "PieControls.git, SingleNodeUserControl_CheckDiskSpace.git, SingleNodeUserControl_CheckFiles.git,"
echo "SingleNodeUserControl_CheckMoonPhase.git, SingleNodeUserControl_CheckServer.git, TextFileLogger.git,"
echo "TimerTrigger.git, TriggerEventMirrorChecker.git, TrueFalseExceptionChecker.git, Vishnu_VSExtensions_64.git,"
echo "WeatherChecker.git, WeatherCheckerControl.git, WebScraper.git, WPFDateDialog.git, WPFDialogChecker.git"
echo "---------------------------------------------------------------------------------------------------"
repoRoot="${Vishnu_Repository}"
if [ "$repoRoot" == "" ]
then
	 repoRoot="git@github.com"
fi
repoBaseUrl="${repoRoot}:InPlug/"
echo "Default Basis-Url: '${repoBaseUrl}'"
echo "---------------------------------------------------------------------------------------------------"
read -r -p "Individuelle Basis-Url (bei Enter Default, Abbruch mit Strg-c): " cs
if [ "$cs" != "" ]
then
	 repoBaseUrl="$cs"
fi
echo "---------------------------------------------------------------------------------------------------"
echo "Basis-Url = '${repoBaseUrl}'"
echo "---------------------------------------------------------------------------------------------------"
for repo in AddOn.git CheckDate.git CheckDiskSpace.git CheckerHistoryLogger CheckServer.git ConsoleLogger.git\
            ConsoleMessageBox.git DateTo_01_15.git DateToMoonAge.git DemoParameterProvider.git DemoWPFCanRunDialog.git\
            Escalator.git FileChecker.git FileWatcherTrigger.git Log2MessageBox.git MicroMailer.git\
            PieControls.git SingleNodeUserControl_CheckDiskSpace.git SingleNodeUserControl_CheckFiles.git\
            SingleNodeUserControl_CheckMoonPhase.git SingleNodeUserControl_CheckServer.git TextFileLogger.git\
            TimerTrigger.git TriggerEventMirrorChecker.git TrueFalseExceptionChecker.git Vishnu_VSExtensions_64.git\
            WeatherChecker.git WeatherCheckerControl.git WebScraper.git WPFDateDialog.git WPFDialogChecker.git;
do
	workOnRepo "$repo" "$repoBaseUrl";
done

echo "--- Ende ---"
