#!/bin/bash
# Script zum clonen aller VishnuHome-Repositories in das aktuelle Verzeichnis.
# 07.06.2020 Erik Nagel: erstellt.

die() { echo "$@" 1>&2 ; exit 1; }

# function for cloning a single remote repo
workOnRepo() {
	repo=$1
	[ -d "./${repo}" ] && die "Das Verzeichnis ./${repo} existiert schon."	
	[ -d "./${repo%.git}" ] && die "Das Verzeichnis ./${repo%.git} existiert schon."	
	repoBasisUrl=${2%/}
	git clone "${repoBasisUrl}/${repo}"
}

# Main
if git rev-parse --git-dir > /dev/null 2>&1; then
 	die "Das Verzeichnis ${pwd} enthaelt schon ein git-Repository. Clone ist hier nicht zulaessig."
fi
echo "Nachfolgende Repositories werden in das aktuelle Verzeichnis $(pwd) gecloned:"
echo "AddOn.git CustomProgressBar.git, Documentation.git, ExpressionParser.git, Install.git,"
echo "Setup.git, Tests.git, TimerMessageBox.git, Vishnu.git, vishnuhome.github.io.git, ZoomBox.git"
echo "---------------------------------------------------------------------------------------------------"
repoRoot="${Vishnu_Repository}"
if [ "$repoRoot" == "" ]
then
	 repoRoot="git@github.com"
fi
repoBaseUrl="${repoRoot}:VishnuHome/"
echo "Default Basis-Url: '${repoBaseUrl}'"
echo "---------------------------------------------------------------------------------------------------"
read -r -p "Individuelle Basis-Url (bei Enter Default, Abbruch mit Strg-c): " cs
if [ "$cs" != "" ]
then
	 repoBaseUrl="$cs"
fi
echo "---------------------------------------------------------------------------------------------------"
echo "Basis-Url = '${repoBaseUrl}'"
echo "---------------------------------------------------------------------------------------------------"
for repo in AddOn.git CustomProgressBar.git Documentation.git ExpressionParser.git Install.git\
            Setup.git Tests.git TimerMessageBox.git Vishnu.git vishnuhome.github.io.git ZoomBox.git;
do
	workOnRepo "$repo" "$repoBaseUrl";
done

echo "--- Ende ---"
