# Assemblies
Enthält alle Framework- und relevanten Vishnu-Assemblies, die von Framework-, Vishnu- und User-Projekten zur Compile-Zeit angezogen werden.
Die Framework-Assemblies (in WorkFrame) referenzieren teilweise einander; aber nicht direkt, sondern über das zentrale Verzeichnis Assemblies (in ReadyBin).
Ebenso referenzieren Vishnu-Assemblies andere Assemblies nicht direkt aus den jeweiligen Framework-Projekten, sondern über dieses Verzeichnis.
Entsprechend verhält es sich mit User-Projekten.
Eine Ausnahme bilden Vishnu-Checker und Vishnu-Viewer, die über die Vishnu-VSExtensions (Visual Studio Erweiterungen) generiert wurden.
Diese enthalten alle notwendigen Assemblies direkt als NuGet-Pakete.
Siehe auch die Vishnu-Hilfe in VishnuHome/Documentation/Vishnu.doc, die Framework-Dokumentation in WorkFrame/NetEti_Framework_doc
und Vishnu_UserChecker_VSIX.vsix und Vishnu_UserView_VSIX.vsix in ...\InPlug\Vishnu_VSExtensions\.
